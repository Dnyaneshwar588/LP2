N = 4

board = [[0 for x in range(N)] for y in range(N)]

def isSafe(board, row, col):

    for i in range(col):
        if board[row][i] == 1:
            return False

    i = row
    j = col

    while i >= 0 and j >= 0:
        if board[i][j] == 1:
            return False
        i -= 1
        j -= 1

    i = row
    j = col

    while j >= 0 and i < N:
        if board[i][j] == 1:
            return False
        i += 1
        j -= 1

    return True


def solveNQ(board, col):

    if col >= N:
        return True

    for i in range(N):

        if isSafe(board, i, col):

            board[i][col] = 1

            if solveNQ(board, col + 1):
                return True

            board[i][col] = 0

    return False


if solveNQ(board, 0):

    for i in board:
        print(i)

else:
    print("Solution does not exist")