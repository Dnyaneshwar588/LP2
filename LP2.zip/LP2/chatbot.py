print("===== Customer Support Chatbot =====")
print("Type 'bye' to exit\n")

while True:
    user = input("You: ").lower()

    if user == "hello" or user == "hi":
        print("Bot: Hello! How can I help you?")

    elif "price" in user:
        print("Bot: Product price starts from Rs. 999")

    elif "delivery" in user:
        print("Bot: Delivery takes 3 to 5 days")

    elif "refund" in user:
        print("Bot: Refund is available within 7 days")

    elif "contact" in user:
        print("Bot: Contact us at support@gmail.com")

    elif user == "bye":
        print("Bot: Thank you! Visit again.")
        break

    else:
        print("Bot: Sorry, I didn't understand.")