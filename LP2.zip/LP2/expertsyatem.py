print("========== HELP DESK EXPERT SYSTEM ==========")

while True:

    print("\nChoose Your Problem")
    print("1. Internet Issue")
    print("2. Password Reset")
    print("3. Computer Slow")
    print("4. Printer Not Working")
    print("5. Exit")

    choice = input("\nEnter your choice: ")

    if choice == '1':
        print("\nSolution:")
        print("-> Restart the router")
        print("-> Check cable connections")
        print("-> Contact ISP if issue continues")

    elif choice == '2':
        print("\nSolution:")
        print("-> Click on 'Forgot Password'")
        print("-> Enter registered email")
        print("-> Create new password")

    elif choice == '3':
        print("\nSolution:")
        print("-> Close unwanted applications")
        print("-> Delete temporary files")
        print("-> Restart the computer")

    elif choice == '4':
        print("\nSolution:")
        print("-> Check printer power")
        print("-> Check USB/WiFi connection")
        print("-> Install printer drivers")

    elif choice == '5':
        print("\nExiting Expert System...")
        break

    else:
        print("\nInvalid Choice")