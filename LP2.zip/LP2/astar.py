graph = {
    'A': {'B': 1, 'C': 3},
    'B': {'D': 3, 'E': 1},
    'C': {'F': 5},
    'D': {},
    'E': {'F': 1},
    'F': {}
}

heuristic = {
    'A': 6,
    'B': 4,
    'C': 4,
    'D': 3,
    'E': 1,
    'F': 0
}

start = 'A'
goal = 'F'

open_list = [start]
closed_list = []

g = {start: 0}

parents = {start: start}

while open_list:

    n = open_list[0]

    for v in open_list:
        if g[v] + heuristic[v] < g[n] + heuristic[n]:
            n = v

    if n == goal:
        path = []

        while parents[n] != n:
            path.append(n)
            n = parents[n]

        path.append(start)
        path.reverse()

        print("Path found:", path)
        break

    for m in graph[n]:

        cost = graph[n][m]

        if m not in open_list and m not in closed_list:

            open_list.append(m)
            parents[m] = n
            g[m] = g[n] + cost

    open_list.remove(n)
    closed_list.append(n)